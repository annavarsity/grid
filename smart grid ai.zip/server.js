const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());

// Dummy AI prediction logic
function predictFailure() {
    const probability = Math.floor(Math.random() * (95 - 60 + 1)) + 60;
    const status = probability > 80 ? "HIGH RISK" : "NORMAL";

    return {
        probability,
        status
    };
}

// API endpoint
app.get("/predict", (req, res) => {
    const result = predictFailure();
    res.json({
        failure_probability: result.probability,
        status: result.status
    });
});

// Server start
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});